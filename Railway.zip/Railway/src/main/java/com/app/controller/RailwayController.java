package com.app.controller;

import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.app.dto.ApiResponse;
import com.app.dto.RailwayDto;
import com.app.exception.ResourceNotFoundException;
import com.app.service.RailwayService;

@RestController
@RequestMapping("/railway")
public class RailwayController {
	@Autowired(required = true)
	private RailwayService railSer;
	

	@PostMapping("/add")
	public ResponseEntity<?> addNewRailway(@RequestBody @Valid RailwayDto railway){
		return new ResponseEntity<RailwayDto>(railSer.addNewRailway(railway), HttpStatus.OK);
	}
	
	@DeleteMapping("/{trainId}")
	public ResponseEntity<?> removeTrainById(@RequestParam Long trainId) {
		String str=railSer.removeTrain(trainId);
		
		return new ResponseEntity<ApiResponse>(new ApiResponse(str), HttpStatus.OK);
	}
	
	@GetMapping("/find")
	public ResponseEntity<?> findRailwayByCategory(@RequestParam String catogery){
		try {
		List<RailwayDto> list=railSer.getRailwayDetails(catogery);
		return new ResponseEntity<>(list, HttpStatus.OK);
		}catch (RuntimeException e) {
			throw new ResourceNotFoundException("Given Catogary of Railway dosent Exists!");
		}
	}
	
	
}
