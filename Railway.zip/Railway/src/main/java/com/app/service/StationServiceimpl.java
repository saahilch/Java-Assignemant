package com.app.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.StationDao;
import com.app.dto.StationDto;
import com.app.exception.ResourceNotFoundException;
import com.app.pojos.Station;


@Service
@Transactional
public class StationServiceimpl implements StationService {
	@Autowired
	private StationDao stationDao;
	
	@Autowired
	private ModelMapper mapper;

	@Override
	public String addStation(StationDto station) {
		Station stat= mapper.map(station, Station.class);
		if(stationDao.save(stat) != null)
		return "Station Added Sucessfully!";
		throw new ResourceNotFoundException("Failed to add the train!");
	}

}
