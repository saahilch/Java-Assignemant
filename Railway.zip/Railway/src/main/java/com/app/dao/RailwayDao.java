package com.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Category;
import com.app.pojos.Railway;

public interface RailwayDao extends JpaRepository<Railway, Long>{
 public List<Railway> findRailwaysByCategory(Category category);
}
