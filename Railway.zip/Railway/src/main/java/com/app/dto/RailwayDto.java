package com.app.dto;

import java.time.LocalDateTime;
import java.time.LocalTime;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotBlank;
import com.app.pojos.Category;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class RailwayDto {
	@NotBlank(message = "Railway Name Can not be blank!")
	private String name;
	@Enumerated(EnumType.STRING)
	private Category category;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
	LocalDateTime startTime;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
	LocalDateTime endTime;
	@NotBlank(message = "Sourse Can not be blank!")
	private String source;
	@NotBlank(message = "Destination Can not be blank!")
	private String destination;
	private Long stationId;
}
