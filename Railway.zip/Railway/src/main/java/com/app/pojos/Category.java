package com.app.pojos;

public enum Category {
EXPRESS,SHATABDI,AC,MERTO;
}
