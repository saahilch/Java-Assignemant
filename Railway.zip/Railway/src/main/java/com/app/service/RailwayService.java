package com.app.service;


import java.util.List;

import com.app.dto.RailwayDto;

public interface RailwayService {

	RailwayDto addNewRailway(RailwayDto railway);

	String removeTrain(Long trainId);

	List<RailwayDto> getRailwayDetails(String category);

}
