package com.app.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StationDto {
	@NotBlank(message = "Station code can not be blank!")
	private String stationCode;
	@NotBlank(message = "Station Name can not be blank!")
	private String stationName;
	@Max(value = 7)
	private int noOfPlatforms;
}
