package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "stations")
@Getter
@Setter
public class Station extends BaseEntity{
	@Column(length = 20)
	private String stationCode;
	@Column(length = 20)
	private String stationName;
	
	private int noOfPlatforms;
	@OneToMany(mappedBy = "station", cascade = CascadeType.ALL, orphanRemoval = true)
	private List <Railway> railways= new ArrayList<>();
	
	
	public Station(String stationCode, String stationName, int noOfPlatforms, List<Railway> railways) {
		super();
		this.stationCode = stationCode;
		this.stationName = stationName;
		this.noOfPlatforms = noOfPlatforms;
		this.railways = railways;
	}
public Station() {
	// TODO Auto-generated constructor stub
}
	public void addRailway(Railway railway) {
		railways.add(railway);
		railway.setStation(this);
	}

	public void removeRailway(Railway railway) {
		railways.remove(railway);
		railway.setStation(null);
	}
	
	@Override
	public String toString() {
		return "Station [stationCode=" + stationCode + ", stationName=" + stationName + ", noOfPlatforms="
				+ noOfPlatforms + "]";
	}
	
	
}
