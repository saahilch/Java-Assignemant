package com.app.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.app.dao.RailwayDao;
import com.app.dao.StationDao;
import com.app.dto.RailwayDto;
import com.app.exception.ResourceNotFoundException;
import com.app.pojos.Category;
import com.app.pojos.Railway;
import com.app.pojos.Station;

@Service
@Transactional
public class RailwayServiceImpl implements RailwayService {
	@Autowired
	private RailwayDao railDao;
	
	@Autowired
	private StationDao stationDao;
	
	@Autowired
	private ModelMapper mapper;

	@Override
	public RailwayDto addNewRailway(RailwayDto railway) {
		Railway rail=mapper.map(railway, Railway.class);
		Station station=stationDao.findById(railway.getStationId()).orElseThrow(()->new ResourceNotFoundException("Station not Exsists"));
		station.addRailway(rail);
		return mapper.map(railDao.save(rail), RailwayDto.class);
	}
	
	
	@Override
	public String removeTrain(Long trainId) {
		Railway rail= railDao.findById(trainId).orElseThrow(()->new ResourceNotFoundException("Train Id dosen't Exsits!"));
		rail.getStation().removeRailway(rail);
		railDao.deleteById(trainId);
		return "Train deleted Sucessfully!!";
	}


	@Override
	public List<RailwayDto> getRailwayDetails(String category) {
		return railDao.findRailwaysByCategory(Category.valueOf(category.toUpperCase())).stream()
		.map(r-> mapper.map(r, RailwayDto.class)).collect(Collectors.toList());
	}
}
