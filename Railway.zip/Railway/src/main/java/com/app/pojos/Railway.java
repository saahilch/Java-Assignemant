package com.app.pojos;

import java.time.LocalDateTime;
import java.time.LocalTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "railways")
public class Railway extends BaseEntity{
	@Column(length = 20)
	private String name;
	@Enumerated(EnumType.STRING)
	private Category category;
	LocalDateTime startTime;
	LocalDateTime endTime;
	@Column(length = 20)
	private String source;
	@Column(length = 20)
	private String destination;
	@ManyToOne
	@JoinColumn(name = "station_id", nullable = false)
	private Station station;
	public Railway() {
		// TODO Auto-generated constructor stub
	}
	
	public Railway(String name, Category category, LocalDateTime startTime, LocalDateTime endTime, String source,
			String destination, Station station) {
		super();
		this.name = name;
		this.category = category;
		this.startTime = startTime;
		this.endTime = endTime;
		this.source = source;
		this.destination = destination;
		this.station = station;
	}

	@Override
	public String toString() {
		return "Railway [name=" + name + ", category=" + category + ", startTime=" + startTime + ", endTime=" + endTime
				+ ", source=" + source + ", destination=" + destination + "]";
	}
	
	
}
